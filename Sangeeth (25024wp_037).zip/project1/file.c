#include <stdio.h>
#include <string.h>
#include "file.h"

/*SAVE CONTACTS*/
void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *fp = fopen("contacts.txt", "w");
    if (!fp) 
    {
        printf("Error opening file for saving!\n");
        return;
    }

    
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        fprintf(fp, "%s,%s,%s\n",
                addressBook->contacts[i].name,
                addressBook->contacts[i].phone,
                addressBook->contacts[i].email);
    }

    fclose(fp);
    printf("Contacts saved successfully.\n");
}

/*LOAD CONTACTS*/
void loadContactsFromFile(AddressBook *addressBook) 
{
    FILE *fp = fopen("contacts.txt", "r");
    if (!fp) 
    {
     
        return;
    }


    fseek(fp, 0, SEEK_END);
    if (ftell(fp) == 0) 
    {
        fclose(fp);
        return; 
    }
    rewind(fp);

    addressBook->contactCount = 0;  

 
    while (fscanf(fp, " %49[^,],%19[^,],%49[^\n]\n",
                  addressBook->contacts[addressBook->contactCount].name,
                  addressBook->contacts[addressBook->contactCount].phone,
                  addressBook->contacts[addressBook->contactCount].email) == 3) 
    {
        addressBook->contactCount++;

        if (addressBook->contactCount >= MAX_CONTACTS) 
        {
            break; 
        }
    }

    fclose(fp);
}
