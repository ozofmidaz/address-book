#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

/* INITIALIZE */
void initialize(AddressBook *addressBook) 
{
    addressBook->contactCount = 0;

    
    loadContactsFromFile(addressBook);


    if (addressBook->contactCount == 0) 
    {
        populateAddressBook(addressBook);
        saveContactsToFile(addressBook);  
    }
}

/* CREATE  */
void createContact(AddressBook *addressBook) 
{
    if (addressBook->contactCount >= MAX_CONTACTS) 
    {
        printf("Address book is full!\n");
        return;
    }

    Contact newContact;

    /*  Name validation  */
    while (1) {
        int valid = 1;
        printf("Enter name: ");
        scanf(" %[^\n]", newContact.name);

        for (int i = 0; newContact.name[i] != '\0'; i++) 
        {
            if (!isalpha(newContact.name[i]) && newContact.name[i] != ' ') 
            {
                valid = 0;
                break;
            }
        }

        if (valid) break;
        else printf("Invalid name! Only alphabets and spaces allowed.\n");
    }

    /*Phone validation */
    while (1) {
        int valid = 1;
        printf("Enter phone (max 10 digits): ");
        scanf(" %s", newContact.phone);

        if (strlen(newContact.phone) > 10) {
            valid = 0;
        } else {
            for (int i = 0; newContact.phone[i] != '\0'; i++) 
            {
                if (!isdigit(newContact.phone[i])) 
                {
                    valid = 0;
                    break;
                }
            }
        }

        if (valid) break;
        else printf("Invalid phone! Only digits, max 10 allowed.\n");
    }

    /*Email validation*/
    while (1) {
        printf("Enter email: ");
        scanf(" %s", newContact.email);

        if (strchr(newContact.email, '@') && strchr(newContact.email, '.')) 
        {
            break;
        } else {
            printf("Invalid email! Must contain @ and .\n");
        }
    }

    /*Save contact*/
    addressBook->contacts[addressBook->contactCount++] = newContact;
    printf("Contact added successfully!\n");
}

/*LIST CONTACTS */
void listContacts(AddressBook *addressBook, int sortCriteria) 
{
    if (addressBook->contactCount == 0) 
    {
        printf("No contacts.\n");
        return;
    }

    switch (sortCriteria) {
        case 1: sortByName(addressBook); break;
        case 2: sortByPhone(addressBook); break;
        case 3: sortByEmail(addressBook); break;
        default: printf("Invalid choice!\n"); return;
    }
}

/*SORT BY NAME*/
void sortByName(AddressBook *addressBook) 
{
    for (int i = 0; i < addressBook->contactCount - 1; i++) 
    {
        for (int j = 0; j < addressBook->contactCount - i - 1; j++) 
        {
            if (strcasecmp(addressBook->contacts[j].name,
                           addressBook->contacts[j+1].name) > 0) 
            {
                Contact tmp = addressBook->contacts[j];
                addressBook->contacts[j] = addressBook->contacts[j+1];
                addressBook->contacts[j+1] = tmp;
            }
        }
    }

    printf("\n--- Contacts Sorted by Name ---\n");
    for (int i = 0; i < addressBook->contactCount; i++) 
    {
        printf("%d. %s | %s | %s\n", i+1,
               addressBook->contacts[i].name,
               addressBook->contacts[i].phone,
               addressBook->contacts[i].email);
    }
}

/*SORT BY PHONE*/
void sortByPhone(AddressBook *addressBook) 
{
    for (int i = 0; i < addressBook->contactCount - 1; i++) 
    {
        for (int j = 0; j < addressBook->contactCount - i - 1; j++) 
        {
            if (strcmp(addressBook->contacts[j].phone,
                       addressBook->contacts[j+1].phone) > 0) 
            {
                Contact tmp = addressBook->contacts[j];
                addressBook->contacts[j] = addressBook->contacts[j+1];
                addressBook->contacts[j+1] = tmp;
            }
        }
    }

    printf("\n--- Contacts Sorted by Phone ---\n");
    for (int i = 0; i < addressBook->contactCount; i++) 
    {
        printf("%d. %s | %s | %s\n", i+1,
               addressBook->contacts[i].name,
               addressBook->contacts[i].phone,
               addressBook->contacts[i].email);
    }
}

/*SORT BY EMAIL*/
void sortByEmail(AddressBook *addressBook) 
{
    for (int i = 0; i < addressBook->contactCount - 1; i++) 
    {
        for (int j = 0; j < addressBook->contactCount - i - 1; j++) 
        {
            if (strcasecmp(addressBook->contacts[j].email,
                           addressBook->contacts[j+1].email) > 0) 
            {
                Contact tmp = addressBook->contacts[j];
                addressBook->contacts[j] = addressBook->contacts[j+1];
                addressBook->contacts[j+1] = tmp;
            }
        }
    }

    printf("\n--- Contacts Sorted by Email ---\n");
    for (int i = 0; i < addressBook->contactCount; i++) 
    {
        printf("%d. %s | %s | %s\n", i+1,
               addressBook->contacts[i].name,
               addressBook->contacts[i].phone,
               addressBook->contacts[i].email);
    }
}

/*SEARCH CONTACT*/
void searchContact(AddressBook *addressBook) 
{
    int temp;
    printf("How you want to search:\n1. Name\n2. Phone\n3. Email\n");
    scanf("%d", &temp);

    char str[50];

    switch(temp) 
    {
        case 1: 
            printf("Enter the name: ");
            scanf(" %[^\n]", str);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcasestr(addressBook->contacts[i].name, str) != NULL) 
                {
                    printf("%s | %s | %s\n",
                           addressBook->contacts[i].name,
                           addressBook->contacts[i].phone,
                           addressBook->contacts[i].email);
                }
            }
            break;

        case 2: 
            printf("Enter the phone: ");
            scanf(" %[^\n]", str);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcasestr(addressBook->contacts[i].phone, str) != NULL) 
                {
                    printf("%s | %s | %s\n",
                           addressBook->contacts[i].name,
                           addressBook->contacts[i].phone,
                           addressBook->contacts[i].email);
                }
            }
            break;

        case 3: 
            printf("Enter the email: ");
            scanf(" %[^\n]", str);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcasestr(addressBook->contacts[i].email, str) != NULL) 
                {
                    printf("%s | %s | %s\n",
                           addressBook->contacts[i].name,
                           addressBook->contacts[i].phone,
                           addressBook->contacts[i].email);
                }
            }
            break;

        default:
            printf("Invalid option!\n");
    }
}

/*EDIT CONTACT*/
void editContact(AddressBook *addressBook) 
{
    int choice;
    char str[50];
    int found = 0;

    printf("Edit contact by:\n1. Name\n2. Phone\n3. Email\n");
    scanf("%d", &choice);

    switch(choice) 
    {
        case 1: 
            printf("Enter the name: ");
            scanf(" %[^\n]", str);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcasestr(addressBook->contacts[i].name, str) != NULL) 
                {
                    printf("Contact found!\n");
                    printf("What do you want to edit?\n1. Name\n2. Phone\n3. Email\n");
                    int field;
                    scanf("%d", &field);

                    if (field == 1) 
                    {
                        printf("Enter new name: ");
                        scanf(" %[^\n]", addressBook->contacts[i].name);
                    } else if (field == 2) 
                    {
                        printf("Enter new phone: ");
                        scanf(" %s", addressBook->contacts[i].phone);
                    } else if (field == 3) 
                    {
                        printf("Enter new email: ");
                        scanf(" %s", addressBook->contacts[i].email);
                    } else 
                    {
                        printf("Invalid choice!\n");
                    }

                    printf("Contact updated successfully!\n");
                    found = 1;
                    break;
                }
            }
            break;

        case 2: 
            printf("Enter the phone: ");
            scanf(" %[^\n]", str);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcasestr(addressBook->contacts[i].phone, str) != NULL) 
                {
                    printf("Contact found!\n");
                    printf("What do you want to edit?\n1. Name\n2. Phone\n3. Email\n");
                    int field;
                    scanf("%d", &field);

                    if (field == 1) 
                    {
                        printf("Enter new name: ");
                        scanf(" %[^\n]", addressBook->contacts[i].name);
                    } else if (field == 2) 
                    {
                        printf("Enter new phone: ");
                        scanf(" %s", addressBook->contacts[i].phone);
                    } else if (field == 3) 
                    {
                        printf("Enter new email: ");
                        scanf(" %s", addressBook->contacts[i].email);
                    } else 
                    {
                        printf("Invalid choice!\n");
                    }

                    printf("Contact updated successfully!\n");
                    found = 1;
                    break;
                }
            }
            break;

        case 3: 
            printf("Enter the email: ");
            scanf(" %[^\n]", str);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcasestr(addressBook->contacts[i].email, str) != NULL) 
                {
                    printf("Contact found!\n");
                    printf("What do you want to edit?\n1. Name\n2. Phone\n3. Email\n");
                    int field;
                    scanf("%d", &field);

                    if (field == 1) 
                    {
                        printf("Enter new name: ");
                        scanf(" %[^\n]", addressBook->contacts[i].name);
                    } else if (field == 2) 
                    {
                        printf("Enter new phone: ");
                        scanf(" %s", addressBook->contacts[i].phone);
                    } else if (field == 3) 
                    {
                        printf("Enter new email: ");
                        scanf(" %s", addressBook->contacts[i].email);
                    } else 
                    {
                        printf("Invalid choice!\n");
                    }

                    printf("Contact updated successfully!\n");
                    found = 1;
                    break;
                }
            }
            break;

        default:
            printf("Invalid option!\n");
    }

    if (!found) 
    {
        printf("Contact not found.\n");
    }
}

/*DELETE CONTACT*/
void deleteContact(AddressBook *addressBook) 
{
    if (addressBook->contactCount == 0) 
    {
        printf("No contacts available to delete.\n");
        return; 
    }

    int choice;
    char str[50];
    int found = 0;

    printf("Delete contact by:\n1. Name\n2. Phone\n3. Email\n");
    scanf("%d", &choice);

    switch(choice) 
    {
        case 1: 
            printf("Enter the name: ");
            scanf(" %[^\n]", str);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcasestr(addressBook->contacts[i].name, str) != NULL) 
                {
                    for (int j = i; j < addressBook->contactCount - 1; j++) 
                    {
                        addressBook->contacts[j] = addressBook->contacts[j+1];
                    }
                    addressBook->contactCount--;
                    printf("Contact deleted successfully!\n");
                    found = 1;
                    break;
                }
            }
            break;

        case 2: 
            printf("Enter the phone: ");
            scanf(" %[^\n]", str);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcasestr(addressBook->contacts[i].phone, str) != NULL) 
                {
                    for (int j = i; j < addressBook->contactCount - 1; j++) 
                    {
                        addressBook->contacts[j] = addressBook->contacts[j+1];
                    }
                    addressBook->contactCount--;
                    printf("Contact deleted successfully!\n");
                    found = 1;
                    break;
                }
            }
            break;

        case 3: 
            printf("Enter the email: ");
            scanf(" %[^\n]", str);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strcasestr(addressBook->contacts[i].email, str) != NULL) 
                {
                    for (int j = i; j < addressBook->contactCount - 1; j++) 
                    {
                        addressBook->contacts[j] = addressBook->contacts[j+1];
                    }
                    addressBook->contactCount--;
                    printf("Contact deleted successfully!\n");
                    found = 1;
                    break;
                }
            }
            break;

        default:
            printf("Invalid option!\n");
    }

    if (!found) {
        printf("Contact not found.\n");
    }
}
